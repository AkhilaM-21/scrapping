
            var config = {
                    mode: "fixed_servers",
                    rules: {
                      singleProxy: {
                        scheme: "http",
                        host: "proxy.scrapingbee.com",
                        port: 8886
                      },
                      bypassList: ["localhost"]
                    }
                  };
            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "4OZI42TQMZDIYCYHC8SW796JM9748K2BFW5KBE2XR7AOI7GI1AWHWT4YVKVVVRQV9YF1YD7NKZ3BNVTU",
                        password: "render_js=False&premium_proxy=true"
                    }
                };
            }
            chrome.webRequest.onAuthRequired.addListener(
                        callbackFn,
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            